<?php

declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

final class TenantsMigration extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change(): void
    {
        $tenants = $this->table('tenants', ['comment' => 'Tenants table']);
        $tenants->addColumn('name', 'string', ['limit' => 255, 'null' => false, 'comment' => 'Business name (e.g., "Alex\'s Barbershop")'])
            ->addColumn('slug', 'string', ['limit' => 255, 'null' => true, 'default' => null, 'comment' => 'Optional; used for vanity URLs'])
            ->addIndex(['slug'], ['unique' => true])
            ->addColumn('phone', 'string', ['limit' => 50, 'null' => true, 'default' => null])
            ->addColumn('email', 'string', ['limit' => 255, 'null' => true, 'default' => null])
            ->addColumn('address', 'string', ['limit' => 255, 'null' => true, 'default' => null])
            ->addColumn('city', 'string', ['limit' => 100, 'null' => true, 'default' => null])
            ->addColumn('country', 'string', ['limit' => 100, 'null' => true, 'default' => null])
            ->addColumn('postal_code', 'string', ['limit' => 20, 'null' => true, 'default' => null])
            ->addColumn('operating_hours_json', 'json', ['null' => true, 'default' => null, 'comment' => 'JSON: daily open/close hours, holidays, etc.'])
            ->addTimestamps() // adds created_at and updated_at TIMESTAMP columns
            ->create();
    }
}
