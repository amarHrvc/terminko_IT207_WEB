<?php

declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

final class USersMigration extends AbstractMigration
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change(): void
    {
        // Users table
        $users = $this->table('users', ['comment' => 'Users table']);
        $users->addColumn('tenant_id', 'integer', ['null' => true, 'signed' => false, 'default' => null, 'comment' => 'Relates to specific tenant if staff; null if customer'])
            ->addColumn('name', 'string', ['limit' => 255, 'null' => false])
            ->addColumn('email', 'string', ['limit' => 255, 'null' => false])
            ->addIndex(['email'], ['unique' => true])
            ->addColumn('password_hash', 'string', ['limit' => 255, 'null' => false])
            ->addColumn('phone', 'string', ['limit' => 50, 'null' => true, 'default' => null])
            ->addColumn('role', 'enum', ['values' => ['owner', 'staff', 'customer'], 'default' => 'customer', 'null' => false, 'comment' => 'User role in the system'])
            ->addTimestamps()
            ->addForeignKey('tenant_id', 'tenants', 'id', ['delete' => 'SET_NULL', 'update' => 'NO_ACTION'])
            ->addIndex(['tenant_id'], ['name' => 'idx_users_tenant_id'])
            ->create();
    }
}
